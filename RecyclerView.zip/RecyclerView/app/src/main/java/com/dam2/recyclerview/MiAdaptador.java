package com.dam2.recyclerview;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Objects;

public class MiAdaptador extends RecyclerView.Adapter<MiAdaptador.MiViewHolder> {

    public static final int TYPE_STANDARD = 0;
    public static final int TYPE_CONTACT = 1;

    private List<Object> listadatos;


    public MiAdaptador(List<Object> listadatos) {
        this.listadatos = listadatos;
    }


    @Override
    public int getItemViewType(int position) {
        Object item = listadatos.get(position);
        if (item instanceof Item) {
            return TYPE_STANDARD;  // 0
        } else if (item instanceof Contacto) {
            return TYPE_CONTACT;   // 1
        }
        return -1;  // Si no es ni uno ni otro, deberías manejar este caso adecuadamente
    }

    @Override
    public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;


        // Inflamos el layout según el tipo de vista
        if (viewType == TYPE_STANDARD) {
            // Para TYPE_STANDARD, inflamos el layout que contiene la imagen y el botón
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_vista, parent, false);
        } else {
            // Para TYPE_CONTACT, inflamos el layout sin el botón y la imagen
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_contactos, parent, false);
        }

        return new MiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MiViewHolder holder, int position) {
        int viewType = getItemViewType(position);

        if (viewType == TYPE_STANDARD) {
            Item item = (Item) listadatos.get(position);
            holder.miTitulo.setText(item.getTitulo());
            holder.miDescripcion.setText(item.getDescripcion());

            // Solo usamos imagenId si no es la posición 1
            if (position != 1 && holder.miImagen != null) {
                holder.miImagen.setVisibility(View.VISIBLE);
                holder.miImagen.setImageResource(item.getImagenId());
            } else if (holder.miImagen != null) {
                holder.miImagen.setVisibility(View.GONE);
            }

            if (position == 1) {
                holder.miBoton.setVisibility(View.VISIBLE);
                holder.pescadoFresco.setVisibility(View.VISIBLE);
                holder.pescadoPodrido.setVisibility(View.GONE);

                holder.miBoton.setOnClickListener(v -> {
                    if (holder.pescadoFresco.getVisibility() == View.VISIBLE) {
                        holder.pescadoFresco.setVisibility(View.GONE);
                        holder.pescadoPodrido.setVisibility(View.VISIBLE);
                        holder.miBoton.setText("Pescado Fresco");
                    } else {
                        holder.pescadoPodrido.setVisibility(View.GONE);
                        holder.pescadoFresco.setVisibility(View.VISIBLE);
                        holder.miBoton.setText("Pescado Podrido");
                    }
                });
            } else {
                if (holder.pescadoFresco != null) holder.pescadoFresco.setVisibility(View.GONE);
                if (holder.pescadoPodrido != null) holder.pescadoPodrido.setVisibility(View.GONE);
                if (holder.miBoton != null) holder.miBoton.setVisibility(View.GONE);
            }
        }
    }


    @Override
    public int getItemCount() {
        return listadatos.size();
    }

    public static class MiViewHolder extends RecyclerView.ViewHolder {
        TextView miTitulo, miDescripcion, nombreContacto, telefonoContacto;
        ImageView miImagen;
        ImageView pescadoFresco, pescadoPodrido;
        Button miBoton;

        public MiViewHolder(View itemView) {
            super(itemView);

            if (itemView.findViewById(R.id.pescado_fresco) != null) {
                pescadoFresco = itemView.findViewById(R.id.pescado_fresco);
            }
            if (itemView.findViewById(R.id.pescado_podrido) != null) {
                pescadoPodrido = itemView.findViewById(R.id.pescado_podrido);
            }

            // Inicializamos las vistas. Si el layout no tiene algunas vistas, estas serán null.
            miTitulo = itemView.findViewById(R.id.mi_titulo);
            miDescripcion = itemView.findViewById(R.id.mi_descripcion);
            nombreContacto = itemView.findViewById(R.id.contacto_nombre);
            telefonoContacto = itemView.findViewById(R.id.contacto_telefono);

            // Solo inicializamos miImagen y miBoton si el layout lo contiene
            if (itemView.findViewById(R.id.mi_imagen) != null) {
                miImagen = itemView.findViewById(R.id.mi_imagen);
            }

            if (itemView.findViewById(R.id.mi_boton) != null) {
                miBoton = itemView.findViewById(R.id.mi_boton);
            }

            boolean esFresco = true;
        }
    }
    }
