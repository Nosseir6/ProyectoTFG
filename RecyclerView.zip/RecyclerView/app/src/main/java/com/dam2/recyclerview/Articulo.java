package com.dam2.recyclerview;

public class Articulo {
    private String titulo;
    private String contenido;

    // Constructor
    public Articulo(String titulo, String contenido) {
        this.titulo = titulo;
        this.contenido = contenido;
    }

    // Métodos getters y setters
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
}
