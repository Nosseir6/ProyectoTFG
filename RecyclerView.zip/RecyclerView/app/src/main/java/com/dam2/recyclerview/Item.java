package com.dam2.recyclerview;

public class Item {
    private String titulo;
    private String descripcion;
    private int imagenId;  // Para la imagen

    // Constructor
    public Item(String titulo, String descripcion, int imagenId) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.imagenId = imagenId;
    }

    // Métodos getter
    public String getTitulo() {
        return titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getImagenId() {
        return imagenId;
    }
}