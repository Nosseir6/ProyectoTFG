package com.dam2.recyclerview;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);



        List<Object> listadatos = new ArrayList<>();
        listadatos.add(new Item("PESCADO","Calidad: El término \"calidad\" en el pescado se refiere generalmente a su apariencia\n" +
                "estética, frescura y el grado de deterioro sufrido, pero también involucra aspectos de\n" +
                "seguridad como la ausencia de bacterias peligrosas, parásitos o compuestos químicos.\n" +
                "Los métodos para evaluar la calidad del pescado fresco se dividen en dos categorías:\n" +
                "sensorial e instrumental. Aunque los métodos instrumentales o químicos pueden ser\n" +
                "útiles, deben correlacionarse con evaluaciones sensoriales, ya que el consumidor es el\n" +
                "último juez de la calidad. Además, los métodos sensoriales deben realizarse de manera\n" +
                "científica, bajo condiciones controladas, para minimizar influencias externas y prejuicios\n" +
                "personales.", R.drawable.pescado));
        listadatos.add(new Item("ESTADOS","Dependiendo del aspecto del pescado podemos deducir su estado",R.drawable.pescado_fresco));

        listadatos.add(new Contacto("Salmón", ""));
        listadatos.add(new Contacto("Lubina", "987-654-321"));
        listadatos.add(new Contacto("Boquerón", "456-789-123"));


        RecyclerView recyclerView = findViewById(R.id.mi_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // Para lista vertical
        MiAdaptador adaptador = new MiAdaptador(listadatos); // listaDatos es la lista que quieres mostrar
        recyclerView.setAdapter(adaptador);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}