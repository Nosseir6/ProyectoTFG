package com.dam2.recyclerview;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

/*public class MiViewHolder extends RecyclerView.ViewHolder {

    ImageView miImagen;
    TextView miTitulo;
    TextView miDescripcion;
    Button miBoton;

    public MiViewHolder(View itemView) {
        super(itemView);
        // Vincular las vistas de item_vista.xml
        miImagen = itemView.findViewById(R.id.mi_imagen);
        miTitulo = itemView.findViewById(R.id.mi_titulo);
        miDescripcion = itemView.findViewById(R.id.mi_descripcion);
        miBoton = itemView.findViewById(R.id.mi_boton);
    }
}*/